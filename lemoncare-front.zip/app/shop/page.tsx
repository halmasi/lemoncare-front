export default function shopPage() {
  return <div>shop page</div>;
}
