export default function dashboard() {
  return <div>page</div>;
}
