'use server';
import { loginSchema } from '@/app/utils/schema/formValidation';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
// export async function signinAction(prevState: any, formData: FormData) {
//   const result = loginSchema.safeParse({
//     email: formData.get('email'),
//     pass: formData.get('pass'),
//   });
//   const data = result.success
//     ? { success: true, data: result.data }
//     : { success: false, data: result.error.flatten() };
//   const response = await fetch(`${process.env.BACKEND_PATH}/auth/local`, {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify({
//       identifier: result.data.email,
//       password: result.data.pass,
//     }),
//   });
//   const { jwt, user } = await response.json();

//   // Store JWT in localStorage or a secure cookie (example here uses localStorage)
//   if (typeof window !== 'undefined') {
//     localStorage.setItem('jwt', jwt);
//   }

//   console.log({
//     ...prevState,
//     data: { success: true, user },
//   });
//   return {
//     ...prevState,
//     data,
//   };
// }
// export async function signinAction(prevState: any, formData: FormData) {
//   console.log('formData:', Array.from(formData.entries())); // Debug the input

//   const result = loginSchema.safeParse({
//     email: formData.get('email'),
//     pass: formData.get('pass'),
//   });

//   if (!result.success) {
//     console.error('Validation errors:', result.error.flatten());
//     return {
//       ...prevState,
//       data: { success: false, data: result.error.flatten() },
//     };
//   }

//   try {
//     const response = await fetch(`${process.env.BACKEND_PATH}/auth/local`, {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify({
//         identifier: result.data.email,
//         password: result.data.pass,
//       }),
//     });
//     console.log(
//       'this is response #######################################3\n',
//       response
//     );
//     if (!response.ok) {
//       const errorData = await response.json();
//       throw new Error(errorData.message || 'Authentication failed');
//     }

//     const { jwt, user } = await response.json();

//     if (typeof window !== 'undefined') {
//       localStorage.setItem('jwt', jwt);
//     }
//     console.log({
//       ...prevState,
//       data: { success: true, user },
//     });
//     return {
//       ...prevState,
//       data: { success: true, user },
//     };
//   } catch (error: any) {
//     console.error('Login error:', error.message);
//     return {
//       ...prevState,
//       data: { success: false, data: { general: error.message } },
//     };
//   }
// }
const config = {
  maxAge: 60 * 60 * 24 * 7, // 1 week

  path: '/',

  domain: process.env.SITE_URL ?? 'localhost',

  httpOnly: true,

  secure: process.env.NODE_ENV === 'production',
};
export async function signinAction(prevState: any, formData: FormData) {
  const data = {
    identifier: formData.get('email'),
    password: formData.get('pass'),
  };

  try {
    const response = await fetch(`${process.env.BACKEND_PATH}/auth/local`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    const responseData = await response.json();

    if (!response.ok) {
      // Handle error case
      throw new Error(responseData.error?.message || 'Authentication failed');
    }

    console.log('Login successful:', responseData);
    const cookieStore = await cookies();

    cookieStore.set('jwt', responseData.jwt, config);
    console.log(cookieStore);
    return {
      ...prevState,
      data: { success: true, user: responseData.user, jwt: responseData.jwt },
    };
  } catch (err: any) {
    console.error('Login error:', err.message);
    return {
      ...prevState,
      data: { success: false, error: err.message },
    };
  }
}

export async function logoutAction() {
  const cookieStore = await cookies();

  cookieStore.set('jwt', '', { ...config, maxAge: 0 });

  redirect('/');
}
