import type { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import NextAuth from 'next-auth';
import { NextAuthOptions, Session, User, Account, JWT } from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';

// export const authConfig: NextAuthOptions = {
//   pages: {
//     signIn: '/login', // Custom sign-in page
//   },
//   callbacks: {
//     async session({ session, token }) {
//       // Pass token data to the session object
//       session.user = token.user ? { ...token.user } : undefined;
//       return session;
//     },
//     async redirect({ url, baseUrl }) {
//       // Redirect logic based on user session or route
//       if (url.startsWith('/dashboard')) {
//         return baseUrl + '/login'; // Redirect to login if unauthenticated
//       }
//       return url.startsWith(baseUrl) ? url : baseUrl;
//     },
//   },
//   providers: [
//     CredentialsProvider({
//       name: 'Credentials',
//       credentials: {
//         email: {
//           type: 'email',
//         },
//         password: { type: 'password' },
//       },
//       async authorize(credentials) {
//         const { email, password } = credentials as {
//           email: string;
//           password: string;
//         };

//         // Make API request to authenticate user
//         const res = await fetch(`${process.env.BACKEND_PATH}/auth/local`, {
//           method: 'POST',
//           headers: { 'Content-Type': 'application/json' },
//           body: JSON.stringify({
//             identifier: email,
//             password: password,
//           }),
//         });

//         if (!res.ok) {
//           const errorData = await res.json();
//           throw new Error(errorData.error?.message || 'Invalid credentials');
//         }

//         const user = await res.json();

//         // Ensure user data is properly returned
//         if (user) {
//           return {
//             id: user.user.id,
//             email: user.user.email,
//             jwt: user.jwt, // Include JWT if needed
//           };
//         }

//         return null;
//       },
//     }),
//   ],
// };

declare module 'next-auth' {
  interface Session {
    jwt: string;
    id: string;
  }

  interface User {
    id: string;
    jwt: string;
  }
}

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? '',
    }),
  ],

  session: {
    strategy: 'jwt', // Use "strategy: 'jwt'" for token-based sessions
  },

  callbacks: {
    async session({ session, token }: { session: Session; token: JWT }) {
      session.jwt = token.jwt;
      session.id = token.id;
      return session;
    },

    async jwt({ token, user, account }) {
      if (account) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/auth/${account.provider}/callback?access_token=${account.access_token}`
        );
        const data = await response.json();

        token.jwt = data.jwt;
        token.id = data.user.id;
      }
      return token;
    },
  },
};

export default NextAuth(authOptions);
